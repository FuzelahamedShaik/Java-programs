package database;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.sql.PreparedStatement;
//import java.sql.SQLException;

public class EmployeeDao {
	
	
	
	public Employee getEmployee(int id, Connection myConnection){
		Employee st = null;
		String url = "jdbc:oracle:thin:@localhost:1521:XE";
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
	                myConnection=DriverManager.getConnection(url,"System","aasri@1999");
			String query= "Select * from Employee where id = ?";

			//Statement myStatement = myConnection.createStatement();
			PreparedStatement pst1 = myConnection.prepareStatement(query);
			pst1.setInt(1, id);
			
			ResultSet rs = pst1.executeQuery();
			if(rs.next()){
				id = rs.getInt(1);
				String name = rs.getString(2);
                                String gen = rs.getString(3);
                                String dept = rs.getString(4);
				double sal = rs.getDouble(5);
				st = new Employee(id, name, gen,dept, sal);
				
			}

			myConnection.close();
		}
		 catch(Exception ex) {
			ex.printStackTrace();
		}
		
		
		return st;
		
	}
	
	public ArrayList<Employee> getAllEmployee(Connection myConnection){
		ArrayList<Employee> allemployee = new ArrayList<>();
		String url = "jdbc:oracle:thin:@localhost:1521:XE";
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			myConnection =DriverManager.getConnection(url,"System","aasri@1999");
			String query= "Select * from Employee order by id";

			Statement myStatement = myConnection.createStatement();
			ResultSet rs = myStatement.executeQuery(query);
			while(rs.next()){
				int id = rs.getInt(1);
				String name = rs.getString(2);
                                String gen = rs.getString(3);
				String dept = rs.getString(4);
				double sal = rs.getDouble(5);
				Employee s = new Employee(id, name, gen, dept, sal);
				allemployee.add(s);
			}

			myConnection.close();
		}
		catch(Exception ex) {
			ex.printStackTrace();
		}
		
		
		return allemployee;
		
	}
	
	public void addEmployee(Employee st){
		
		String url = "jdbc:oracle:thin:@localhost:1521:XE";
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection myConnection = 
			DriverManager.getConnection(url,"System","aasri@1999");
			String query= "insert into Employee values(?,?,?,?,?)";
			
			//Statement myStatement = myConnection.createStatement();
			PreparedStatement pst1 = myConnection.prepareStatement(query);
			pst1.setInt(1, st.getId());
			pst1.setString(2, st.getName());
                        pst1.setString(3, st.getGen());
                        pst1.setString(4, st.getDept());
			pst1.setDouble(5, st.getSal());
			
			pst1.executeUpdate();
			System.out.println("Employee details inserted successfully...");

			myConnection.close();
		}
		catch(Exception ex) {
			ex.printStackTrace();
		}
		
		
	}
       
   
}
