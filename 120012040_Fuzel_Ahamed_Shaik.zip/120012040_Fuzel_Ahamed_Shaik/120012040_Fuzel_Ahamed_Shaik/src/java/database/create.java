/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package database;

/**
 *
 * @author Lenovo
 */


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.sql.ResultSet;

public class create {

	public static void main(String[] args) {
		String url = "jdbc:oracle:thin:@localhost:1521:XE";
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection myConnection =DriverManager.getConnection(url,"System","aasri@1999");
			System.out.println("Connected");         
			Statement myStatement = myConnection.createStatement();
                        String query="CREATE TABLE Employee " +
                         "(id INTEGER not NULL, " +
                         " name VARCHAR(255), " + 
                          " gen VARCHAR(255), " +
                         " dept VARCHAR(255), " + 
                         " sal FLOAT, " + 
                         " PRIMARY KEY ( id ))"; 
                            myStatement.executeUpdate(query);
                        
                        System.out.println("DATA BASE created");

			myConnection.close();
		}
		catch(java.lang.Exception ex) {
			ex.printStackTrace();
		}


	}

}
