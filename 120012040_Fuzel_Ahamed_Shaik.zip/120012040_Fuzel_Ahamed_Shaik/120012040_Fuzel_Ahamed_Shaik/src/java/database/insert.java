/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package database;

/**
 *
 * @author Lenovo
 */

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.sql.ResultSet;

public class insert {

	public static void main(String[] args) {
		String url = "jdbc:oracle:thin:@localhost:1521:XE";
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection myConnection =DriverManager.getConnection(url,"System","aasri@1999");
			System.out.println("Connected");         
			Statement myStatement = myConnection.createStatement();
                        String query="INSERT INTO Employee " +
                   "VALUES (102, 'Sravs', 'Female','Production',45000)";
                            myStatement.executeUpdate(query);
                        System.out.println("Record Added Successfully");

			myConnection.close();
		}
		catch(java.lang.Exception ex) {
			ex.printStackTrace();
		}


	}

}

