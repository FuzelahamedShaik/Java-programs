/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package database;

/**
 *
 * @author Lenovo
 */
public class Employee {
    private int id;
	private String name;
        private String gen;
        private String dept;
	private double sal;
	public Employee() {
		super();
	}
	public Employee(int id, String name,String gen,String dept,double sal) {
		super();
		this.id = id;
		this.name = name;
		this.sal = sal;
                this.gen = gen;
		this.dept = dept;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
        
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
        public String getGen() {
		return gen;
	}
	public void setGen(String gen) {
		this.gen =gen;
	}
         public String getDept() {
		return dept;
	}
	public void setDept(String dept) {
		this.dept =dept;
	}
	public double getSal() {
		return sal;
	}
	public void setSal(double sal) {
		this.sal =sal;
	}
	@Override
	public String toString() {
		return "Employee [id=" + id + ", name=" + name + ", Sal=" + sal + "]";
	}
	
    
}
