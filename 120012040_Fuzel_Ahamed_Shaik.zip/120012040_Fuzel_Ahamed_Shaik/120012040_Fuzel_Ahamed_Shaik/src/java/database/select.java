/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package database;

/**
 *
 * @author Lenovo
 */


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.sql.ResultSet;

public class select{

	public static void main(String[] args) {
		String url = "jdbc:oracle:thin:@localhost:1521:XE";
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection myConnection =DriverManager.getConnection(url,"System","aasri@1999");
			System.out.println("Connected");         
			Statement myStatement = myConnection.createStatement();
                        String query="select * from Employee";
                               
                             
                        
                        
                     
			ResultSet rs=myStatement.executeQuery(query);
                        System.out.println("Empid" + " Name " + " Gender " +"  Dept   " +   "   Salary ");
			while(rs.next()){
				int id = rs.getInt(1);
				String name = rs.getString(2);
                                String gen = rs.getString(3);
                                String dept = rs.getString(4);
				
				double sal = rs.getDouble(5);
				System.out.println( id + "  " + name +"  " +gen+"   " +dept+"   " + sal );
			}
                        System.out.println("Records Displayed Successfully");

			myConnection.close();
		}
		catch(java.lang.Exception ex) {
			ex.printStackTrace();
		}


	}

}

